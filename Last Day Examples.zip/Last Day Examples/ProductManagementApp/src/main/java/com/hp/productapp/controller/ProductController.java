package com.hp.productapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hp.productapp.entity.Product;
import com.hp.productapp.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	@Autowired
	ProductService service;

	@PostMapping("/addproduct")
	public String insertProduct(@RequestBody Product product) {
		return service.addProduct(product);
	}

	@PutMapping("/updateproduct")
	public String updateProduct(@RequestBody Product product) {
		return service.updateProduct(product);
	}

	@DeleteMapping("/deleteproduct/{id}")
	public String deleteProduct(@PathVariable("id") int productId) {
		return service.deleteProduct(productId);
	}

	@GetMapping("/getproduct/{id}")
	public Product getProduct(@PathVariable("id") int productId) {
		return service.getProduct(productId);
	}

	@GetMapping("/getproducts")
	public List<Product> getAllProducts() {
		return service.GetAllProducts();
	}

	@GetMapping("/getallproducts/{iprice}/{fprice}")
	public List<Product> getAllProductsInBetween(@PathVariable("iprice") int intialPrice,
			@PathVariable("fprice") int finalPrice) {
		return service.getAllProductsByPriceRange(intialPrice, finalPrice);
	}

	@GetMapping("/getproducts/{category}")
	public List<Product> getAllProductByCategory(@PathVariable("category") String productCategory) {
		return service.getAllProductsByCategory(productCategory);
	}
}
