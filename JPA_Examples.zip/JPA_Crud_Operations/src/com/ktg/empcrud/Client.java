package com.ktg.empcrud;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("sleeping");
		EntityManager entityManager = factory.createEntityManager();// persist()-->insert,merge()-->update,remove()-->delete,find()-->select
		//Employee emp = new Employee(124, "rajesh", 43000, "delhi");
		entityManager.getTransaction().begin();
		// entityManager.persist(emp);
		Employee emp1 = entityManager.find(Employee.class, 123);
		System.out.println(emp1);
//		emp1.setEmpAdd("noida");
//		emp1.setEmpSal(12000);
//		entityManager.merge(emp1);
		entityManager.remove(emp1);
		entityManager.getTransaction().commit();
		System.out.println("Data Inserted");

	}

}
