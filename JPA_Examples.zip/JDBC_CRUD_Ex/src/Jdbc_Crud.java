import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Jdbc_Crud {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// loading the driver class
		Class.forName("com.mysql.cj.jdbc.Driver");
		// creating the connection
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ktg", "root", "rpsconsulting");
		// creating the statement
		Statement stmt = conn.createStatement();
		// executing the query
		// execute()-->DDL,executeUpdate()-->DML,executeQuery()-->DRL
//		boolean result = stmt.execute("create table emps1(eid int,ename varchar(10))");
		// int result=stmt.executeUpdate("insert into emps1 values(1,'suresh')");
		// int result=stmt.executeUpdate("update emps1 set ename='naresh' where eid=1");
	//	int result = stmt.executeUpdate("delete from emps1");
		
			ResultSet rs=stmt.executeQuery("select * from emps1");
		while(rs.next())
		{
			System.out.println(rs.getInt(1)+" "+rs.getString("ename"));
		}
		// closing the connection
		conn.close();
		
	}

}
